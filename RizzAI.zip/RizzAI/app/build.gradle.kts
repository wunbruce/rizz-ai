plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.rizzai"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rizzai"
        minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0"
        // Your backend that holds the Claude API key. Never put the key in the APK.
        buildConfigField("String", "API_URL", "\"https://YOUR-SERVER.example.com/rizz\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
}
