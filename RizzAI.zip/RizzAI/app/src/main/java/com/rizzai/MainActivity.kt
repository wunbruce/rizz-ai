package com.rizzai

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Lav = Color(0xFF9B7BFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("rizz", MODE_PRIVATE)
        setContent {
            var consent by remember { mutableStateOf(prefs.getBoolean("consent", false)) }
            Column(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A1330), Color(0xFF0B0B0F))))
                    .statusBarsPadding().padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("RIZZ AI", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
                Text("Your AI wingman, wherever you text.", color = Color(0xFFB9A8FF), fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                Step("1  Enable the keyboard", "Turn on RIZZ AI Keyboard, then pick it when typing.") {
                    startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                }
                Step("2  Turn on the chat reader", "Accessibility → RIZZ AI Chat Reader. It reads visible messages only when you tap RIZZ AI.") {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                Card(Modifier.fillMaxWidth().animateContentSize(), shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF16141D))) {
                    Row(Modifier.padding(18.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("3  Allow sending chat text", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Visible chat text is sent to our server to write replies. Never from password fields. Not stored.", color = Color(0xFFAAAAAA), fontSize = 14.sp)
                        }
                        Switch(consent, { consent = it; prefs.edit().putBoolean("consent", it).apply() })
                    }
                }
            }
        }
    }
}

@Composable
private fun Step(title: String, body: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF16141D))) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(body, color = Color(0xFFAAAAAA), fontSize = 14.sp)
            Button(onClick, colors = ButtonDefaults.buttonColors(containerColor = Lav), shape = RoundedCornerShape(20.dp)) { Text("Open settings") }
        }
    }
}
