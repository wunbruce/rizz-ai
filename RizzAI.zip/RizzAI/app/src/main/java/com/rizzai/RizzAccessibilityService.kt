package com.rizzai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Reads on-screen text (the same tree TalkBack uses) ONLY when the keyboard asks. Nothing is stored. */
class RizzAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun readChat(): List<String> {
        val out = ArrayList<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= 40) return
            if (n.isPassword) return
            val t = n.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && !n.isEditable && t.length < 500) out.add(t)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return out.takeLast(20)
    }

    companion object { var instance: RizzAccessibilityService? = null }
}
