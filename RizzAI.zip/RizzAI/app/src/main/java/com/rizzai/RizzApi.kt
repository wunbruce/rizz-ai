package com.rizzai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** POST {context:[..], vibe:".."} -> {replies:[".."]}. Your server calls Claude with the secret key. */
object RizzApi {
    fun replies(context: List<String>, vibe: String): List<String> {
        val c = URL(BuildConfig.API_URL).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 10000; c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject().put("context", JSONArray(context)).put("vibe", vibe)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = c.inputStream.bufferedReader().readText()
        val arr = JSONObject(txt).getJSONArray("replies")
        return List(arr.length()) { arr.getString(it) }
    }
}
