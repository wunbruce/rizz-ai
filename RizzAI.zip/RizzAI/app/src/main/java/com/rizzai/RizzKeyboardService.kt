package com.rizzai

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.*

class RizzKeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private var vibe = "Flirty"
    private lateinit var panel: LinearLayout
    private lateinit var results: LinearLayout
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int = 12) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun btn(t: String, w: Float = 1f, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); background = bg(0xFF26232F.toInt())
        layoutParams = LinearLayout.LayoutParams(0, dp(46), w).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        setOnClickListener { onClick() }
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0B0B0F.toInt()); setPadding(dp(4), dp(4), dp(4), dp(4)) }

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; background = bg(0xFF16141D.toInt(), 20); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        panel.addView(TextView(this).apply { text = "😏 RIZZ AI  ·  What vibe?"; setTextColor(Color.WHITE); textSize = 16f })
        val vibes = listOf("😏 Flirty", "😂 Funny", "😎 Smooth", "🔥 Bold", "😌 Low-key", "👀 Playful")
        vibes.chunked(3).forEach { row ->
            val l = LinearLayout(this)
            row.forEach { v -> l.addView(btn(v) { vibe = v.substringAfter(' '); status.text = "Vibe: $vibe" }) }
            panel.addView(l)
        }
        panel.addView(Button(this).apply {
            text = "✨ Generate"; isAllCaps = false; setTextColor(Color.WHITE); background = bg(0xFF9B7BFF.toInt(), 24)
            setOnClickListener { generate() }
        })
        status = TextView(this).apply { setTextColor(0xFFB9A8FF.toInt()); text = "Vibe: $vibe"; setPadding(0, dp(6), 0, dp(4)) }
        panel.addView(status)
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(ScrollView(this).apply { addView(results); layoutParams = LinearLayout.LayoutParams(-1, dp(150)) })
        root.addView(panel)

        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        rows.forEach { r ->
            val l = LinearLayout(this).apply { gravity = Gravity.CENTER }
            r.forEach { ch -> l.addView(btn(ch.toString()) { currentInputConnection?.commitText(ch.toString(), 1) }) }
            root.addView(l)
        }
        val bottom = LinearLayout(this)
        bottom.addView(btn("✨ RIZZ AI", 2f) { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }.apply { background = bg(0xFF9B7BFF.toInt()) })
        bottom.addView(btn("space", 4f) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(btn("⌫", 1.2f) { currentInputConnection?.deleteSurroundingText(1, 0) })
        bottom.addView(btn("↵", 1.2f) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) })
        root.addView(bottom)
        return root
    }

    private fun generate() {
        val prefs = getSharedPreferences("rizz", MODE_PRIVATE)
        val svc = RizzAccessibilityService.instance
        if (!prefs.getBoolean("consent", false) || svc == null) {
            status.text = "Open the RIZZ AI app to finish setup."; return
        }
        status.text = "Reading the chat…"; results.removeAllViews()
        val context = svc.readChat()
        Thread {
            try {
                val replies = RizzApi.replies(context, vibe)
                ui.post { status.text = "Tap a reply to insert it 👇"; replies.forEach { addReply(it) } }
            } catch (e: Exception) { ui.post { status.text = "Couldn't reach RIZZ AI. Try again." } }
        }.start()
    }

    private fun addReply(t: String) = results.addView(TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 15f; background = bg(0xFF26232F.toInt(), 16); setPadding(dp(12), dp(10), dp(12), dp(10))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) }
        setOnClickListener { currentInputConnection?.commitText(t, 1); panel.visibility = View.GONE }
    })
}
